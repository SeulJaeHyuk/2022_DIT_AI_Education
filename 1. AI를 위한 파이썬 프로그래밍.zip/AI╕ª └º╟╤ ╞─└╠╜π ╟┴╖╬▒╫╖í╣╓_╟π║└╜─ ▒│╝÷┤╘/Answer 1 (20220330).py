a = input()
for i in range(len(a)) :
    for j in range(i) :
        print( a[j], end = '')
    print()
