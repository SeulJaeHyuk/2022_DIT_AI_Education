Python 3.10.3 (tags/v3.10.3:a342a49, Mar 16 2022, 13:07:40) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
a = 100
b = 200
sum = a + b
print(a, " + ", b, " = ", sum)
100  +  200  =  300
a = 10
b = 3.141592
print("a=%d, b=%f"%(a,b))
a=10, b=3.141592
print("a=%10d, b=%f"%(a,b))
a=        10, b=3.141592
print("a=%-10d, b=%f"%(a, b))
a=10        , b=3.141592
print("a=%-10d, b=%.3f"%(a, b))
a=10        , b=3.142
print("a=%-10d, b=%10.3f"%(a, b))
a=10        , b=     3.142
print("a={}, b={}".format(a, b))
a=10, b=3.141592
print("a={1}, b={0}".format(a, b))
a=3.141592, b=10
print("a={forA} b={forB}". format(forA=b, forB=a))
a=3.141592 b=10
print("DIT")
DIT
print("DIT")
DIT
print("Hello Python")
Hello Python
print("Hello Python", end="!!!")
Hello Python!!!
print("Korea", "Japan", "China", sep="/")
Korea/Japan/China
print("Korea", "Japan", "China")
Korea Japan China
name = input("당신의 이름은?")
당신의 이름은? 홍길동
name
' 홍길동'
print("안녕하세요, %s씨!"%(name))
안녕하세요,  홍길동씨!
print("안녕하세요, {}씨!".format(name))
안녕하세요,  홍길동씨!
a = input("정수입력:")
정수입력:55
b = a * 2

print(b)
5555
"DIT"*10
'DITDITDITDITDITDITDITDITDITDIT'
a = int(input("정수입력:"))
정수입력:123654
b = a * 2
print(b)
247308
["apple", "mango", "banana", "kiwi"]
['apple', 'mango', 'banana', 'kiwi']
fruits = ["apple", "mango", "banana", "kiwi"]
fruits
['apple', 'mango', 'banana', 'kiwi']
print(fruits)
['apple', 'mango', 'banana', 'kiwi']
for fruit in fruits:
        print("I like %s."%fruit))
        
SyntaxError: unmatched ')'
for fruit in fruits:
        print("I like %s."%(fruit))

        
I like apple.
I like mango.
I like banana.
I like kiwi.

========================================================================== RESTART: C:/Users/tbn29/OneDrive/문서/AI Python/fruits.py ==========================================================================
I like apple.
I like mang.
I like banana.
I like kiwi.

============ RESTART: C:/Users/tbn29/OneDrive/문서/AI Python/fruits.py ===========
I like apple.very much.
I like mang.very much.
I like banana.very much.
I like kiwi.very much.
range)5_
SyntaxError: unmatched ')'
range(5)
range(0, 5)
print(range(5))
range(0, 5)
for i in range(5)
SyntaxError: expected ':'
for i in range(5):
    print(i)

    
0
1
2
3
4

========== RESTART: C:/Users/tbn29/OneDrive/문서/AI Python/rangeTest.py ==========
Traceback (most recent call last):
  File "C:/Users/tbn29/OneDrive/문서/AI Python/rangeTest.py", line 2, in <module>
    for i in range(5, 10, 0.3):
TypeError: 'float' object cannot be interpreted as an integer

========== RESTART: C:/Users/tbn29/OneDrive/문서/AI Python/rangeTest.py ==========
5
7
9
