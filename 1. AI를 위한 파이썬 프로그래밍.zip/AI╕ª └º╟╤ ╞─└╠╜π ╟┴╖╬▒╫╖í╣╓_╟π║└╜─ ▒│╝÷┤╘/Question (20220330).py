ABCDEFGH

#1
st = "ABCDEFGH"
A
AB
ABC
ABCD
...
ABCDEFGH

#2
A
  B
    C
      D
        E
          F
            G
              H
